document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.getElementById("register-form");
    const loginForm = document.getElementById("login-form");

    // ✅ Регистрация пользователя
    if (registerForm) {
        registerForm.addEventListener("submit", async (event) => {
            event.preventDefault();

            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;

            const response = await fetch("http://127.0.0.1:8000/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, email, password })
            });

            const data = await response.json();
            document.getElementById("register-message").textContent = data.message;

            if (response.ok) {
                alert("Регистрация успешна! Теперь войдите.");
                window.location.href = "login.html";  // ✅ Перенаправление на страницу входа
            }
        });
    }

    // ✅ Вход пользователя
    if (loginForm) {
        loginForm.addEventListener("submit", async (event) => {
            event.preventDefault();

            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;

            const formData = new URLSearchParams();
            formData.append("username", email);
            formData.append("password", password);

            const response = await fetch("http://127.0.0.1:8000/login", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: formData
            });

            const data = await response.json();
            document.getElementById("login-message").textContent = data.detail || "Вход выполнен!";

            if (response.ok) {
                localStorage.setItem("token", data.access_token);
                localStorage.setItem("userEmail", email); // ✅ Сохраняем email пользователя
                alert("Вы вошли в систему!");
                window.location.href = "index.html";  // ✅ Перенаправление на главную страницу
            }
        });
    }

    // ✅ Проверка, вошёл ли пользователь
    const userInfo = document.getElementById("user-info");
    if (userInfo) {
        const userEmail = localStorage.getItem("userEmail");
        if (userEmail) {
            userInfo.innerHTML = `<p>Вы вошли как: <strong>${userEmail}</strong></p>
                                  <button id="logout">Выйти</button>`;

            document.getElementById("logout").addEventListener("click", () => {
                localStorage.removeItem("token");
                localStorage.removeItem("userEmail");
                alert("Вы вышли из системы.");
                window.location.href = "login.html";  // ✅ Перенаправление на страницу входа
            });
        } else {
            userInfo.innerHTML = "<p>Вы не вошли в систему.</p>";
        }
    }
});
