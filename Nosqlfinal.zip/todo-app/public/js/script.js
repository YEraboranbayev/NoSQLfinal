document.addEventListener("DOMContentLoaded", () => {
    console.log("Script loaded!");

    const loginForm = document.getElementById("login-form");
    const loginMessage = document.getElementById("login-message");
    const userInfo = document.getElementById("user-info");
    const deleteButton = document.getElementById("delete-profile");
    const bikeList = document.getElementById("bike-list");
    const cartList = document.getElementById("cart-list");
    const clearCartButton = document.getElementById("clear-cart");
    const userList = document.getElementById("user-list");
    const orderList = document.getElementById("order-list");


    // ✅ Проверяем, есть ли пользователь
    const user = JSON.parse(localStorage.getItem("user"));

    if (userInfo) {
        if (user) {
            userInfo.innerHTML = `<p>Вы вошли как: <strong id="user-email">${user.email}</strong></p>`;
            if (deleteButton) {
                deleteButton.style.display = "block";
            }
        } else {
            userInfo.innerHTML = "<p>Вы еще не вошли в систему.</p>";
            deleteButton.style.display = "none";
        }
    }

    // ✅ Обработчик формы входа
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;

            if (/^\d{6,}$/.test(password)) {
                localStorage.setItem("user", JSON.stringify({ email }));

                loginMessage.textContent = "Успешный вход!";
                loginMessage.style.color = "green";

                setTimeout(() => {
                    window.location.href = "profile.html";
                }, 1000);
            } else {
                loginMessage.textContent = "Пароль должен содержать минимум 6 цифр!";
                loginMessage.style.color = "red";
            }
        });
    }

    // ✅ Удаление профиля
    if (deleteButton) {
        deleteButton.addEventListener("click", () => {
            if (confirm("Вы уверены, что хотите удалить профиль?")) {
                localStorage.removeItem("user");
                alert("Профиль удален!");
                window.location.href = "index.html";
            }
        });
    }

    // ✅ Загрузка велосипедов
    async function loadBikes() {
        if (!bikeList) return;

        try {
            const response = await fetch("http://127.0.0.1:8000/bikes");
            const data = await response.json();

            bikeList.innerHTML = "";

            data.bikes.forEach(bike => {
                const bikeElement = document.createElement("div");
                bikeElement.classList.add("bike-card");

                bikeElement.innerHTML = `
                    <img src="${bike.image}" alt="${bike.title}">
                    <h3>${bike.title}</h3>
                    <p class="price">${bike.price}</p>
                    <button class="add-to-cart" data-bike='${JSON.stringify(bike)}'>Добавить в корзину</button>
                `;

                bikeList.appendChild(bikeElement);
            });

            document.querySelectorAll(".add-to-cart").forEach(button => {
                button.addEventListener("click", (e) => {
                    const bike = JSON.parse(e.target.getAttribute("data-bike"));
                    addToCart(bike);
                });
            });

        } catch (error) {
            console.error("Ошибка загрузки данных:", error);
        }
    }

    // ✅ Добавление в корзину
    function addToCart(bike) {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(bike);
        localStorage.setItem("cart", JSON.stringify(cart));
        alert("Добавлено в корзину!");
    }

    // ✅ Загрузка корзины
    function loadCart() {
        if (!cartList) return;
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cartList.innerHTML = "";

        if (cart.length === 0) {
            cartList.innerHTML = "<p>Корзина пуста.</p>";
            return;
        }

        cart.forEach((bike, index) => {
            const bikeElement = document.createElement("div");
            bikeElement.classList.add("bike-card");

            bikeElement.innerHTML = `
                <img src="${bike.image}" alt="${bike.title}">
                <h3>${bike.title}</h3>
                <p class="price">${bike.price}</p>
                <button class="remove-from-cart" data-index="${index}">Удалить</button>
            `;

            cartList.appendChild(bikeElement);
        });

        document.querySelectorAll(".remove-from-cart").forEach(button => {
            button.addEventListener("click", (e) => {
                const index = e.target.getAttribute("data-index");
                removeFromCart(index);
            });
        });
    }

    // ✅ Удаление из корзины
    function removeFromCart(index) {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.splice(index, 1);
        localStorage.setItem("cart", JSON.stringify(cart));
        loadCart();
    }

    // ✅ Очистка корзины
    if (clearCartButton) {
        clearCartButton.addEventListener("click", () => {
            localStorage.removeItem("cart");
            loadCart();
        });
    }
  // ✅ Загружаем список пользователей
  async function loadUsers() {
    if (!userList) return;

    try {
        const response = await fetch("http://127.0.0.1:8000/users");
        const data = await response.json();

        userList.innerHTML = ""; // Очищаем перед добавлением новых данных

        data.users.forEach(user => {
            const userElement = document.createElement("p");
            userElement.textContent = `${user.name} (${user.role})`;
            userList.appendChild(userElement);
        });
    } catch (error) {
        console.error("Ошибка загрузки пользователей:", error);
    }
}

// ✅ Загружаем список заказов
async function loadOrders() {
    if (!orderList) return;

    try {
        const response = await fetch("http://127.0.0.1:8000/orders");
        const data = await response.json();

        orderList.innerHTML = ""; // Очищаем перед добавлением новых данных

        data.orders.forEach(order => {
            const orderElement = document.createElement("p");
            orderElement.textContent = `Заказ ${order._id}: Пользователь ${order.userId} заказал велосипед ${order.bikeId} (статус: ${order.status})`;
            orderList.appendChild(orderElement);
        });
    } catch (error) {
        console.error("Ошибка загрузки заказов:", error);
    }
}
    loadUsers();
    loadOrders();
    loadBikes();
    loadCart();
});
